# JDR 书源开发工具包

编写 Timbre 书源只需要这个文件夹 + 电脑上装有 Node.js 18+（nodejs.org 下载，或手机 Termux）。**不需要下载 Timbre 播放器源码。**

## 30 秒上手

```bash
# 1. 从模板创建你的书源包
node source-kit/bin/source-kit.js new my-sources

# 2. 编辑 my-sources/manifest.json 和 my-sources/bundle.js
#    教程：docs/jdr-tutorial.md（手把手，先读这个）
#          docs/jdr-plugin.md（API 速查表）
#    现成例子：examples/ 三个完整源码，改掉 example.com 就能用

# 3. 离线测试（不需要真实网站，会给你假数据走全流程）
node source-kit/bin/source-kit.js test my-sources

# 4. 打包 → 生成 my-sources.jdr
node source-kit/bin/source-kit.js pack my-sources
```

把 .jdr 放到手机 / 传到任意网址 → Timbre → 设置 → 在线书源 → 书源插件 → 导入。

## 编写时改哪里

- `bundle.js`：实现 search / chapters / audio 三个函数（教程第 3、4 节有字段表和完整代码）
- `manifest.json`：改 packageId（小写，定了就别改）和 sources 列表

## 示例对照

| examples/ | 场景 | 教程章节 |
|---|---|---|
| demo-json | 站点有 JSON 接口（最常见） | 5.1 |
| demo-html | 只有网页，正则解析 | 5.2 |
| demo-headers | 防盗链：直链要带 Referer/Cookie | 5.3 |

examples 里同名 .jdr 是已打好的包，可直接导入 App 试玩。
